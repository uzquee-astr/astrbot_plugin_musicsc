# musicsc
 这是一款网易云的音乐搜索插件目前测试中，有问题请反馈
 邮箱:Clbro981154@outlook.com